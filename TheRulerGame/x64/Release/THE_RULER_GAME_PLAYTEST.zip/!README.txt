
CONTROLS
-------------------
PLAYER ONE:
W - Move Forward
A/D - Rotate
Space - Attack
S - Special Attack (when holding pickup)

PLAYER TWO:
Up Arrow - Move Forward
Left/Right Arrows - Rotate
CTRL - Attack
Down Arrow - Special Attack (when holding pickup)



PICKUPS
-------------------
LASER (Orange):
Hold Special Attack to use. Unleashes a giant overpowered laser that can pass through walls.

BOMB (Red):
Press Special Attack to use. Drops a bomb that explodes after a few seconds, sending projectiles in every direction.

ATTACK SPEED (Green):
Attack while holding Special Attack to use. Attack speed is increased while Special Attack is held down.



NOTES
-------------------
Players lose pickups after a short time.
Several options can be tweaked in the Options menu.
More pickups are planned for the final release.
Some sounds and improved sprites have not yet been implemented.